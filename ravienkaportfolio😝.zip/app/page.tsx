
export default function Home() {
  return (
    <main className="bg-black text-white min-h-screen w-full font-sans">
      <section
        className="h-screen w-full flex flex-col justify-center items-center text-center px-4 bg-cover bg-center relative"
        style={{ backgroundImage: "url('/wavebg.png')" }}
      >
        <h1 className="text-6xl md:text-7xl font-extrabold bg-gradient-to-r from-pink-500 via-purple-500 to-pink-500 text-transparent bg-clip-text animate-fade-up">
          Ravien
        </h1>
        <p className="mt-6 text-lg text-gray-300 max-w-xl animate-fade-up delay-150">
          Full Stack Developer — Sleek, Fast, Powerful Interfaces
        </p>
        <a
          href="#portfolio"
          className="mt-10 px-6 py-3 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full font-medium text-white shadow-md hover:shadow-xl transition duration-300 animate-fade-up delay-300"
        >
          View Portfolio
        </a>
      </section>

      <section id="portfolio" className="py-20 px-4 bg-[#111] text-white">
        <h2 className="text-4xl font-bold text-center mb-12 animate-fade-up">Portfolio</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {["Landing Page UI", "Crypto Dashboard", "Terminal Design", "NFT Portfolio", "AI Chat UI", "Game Promo Site"].map((title, i) => (
            <div key={i} className="bg-[#1a1a1a] rounded-xl p-6 border border-pink-600 shadow-md hover:scale-[1.03] hover:shadow-xl transition-all duration-300 animate-fade-up">
              <h3 className="text-xl font-semibold mb-2 text-pink-400">{title}</h3>
              <p className="text-gray-400">Sleek and modern design showcasing performance and creativity.</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-20 px-6 bg-black text-white">
        <h2 className="text-4xl font-bold text-center mb-8 animate-fade-up">About Me</h2>
        <div className="max-w-3xl mx-auto text-center text-gray-300 text-lg animate-fade-up">
          <p>
            I’m <span className="text-pink-400 font-semibold">Ravien</span>, a passionate full stack developer who
            builds futuristic websites and interfaces with focus on minimalism, speed, and design.
          </p>
        </div>
      </section>

      <section className="py-20 px-6 bg-[#111] text-white">
        <h2 className="text-4xl font-bold text-center mb-8 animate-fade-up">Contact</h2>
        <div className="max-w-xl mx-auto text-center animate-fade-up">
          <p className="text-gray-300 mb-6">Have a project in mind? Let’s connect.</p>
          <a href="mailto:ravien@yourmail.com" className="inline-block px-6 py-3 bg-pink-600 hover:bg-pink-700 transition-all rounded-full text-white font-semibold">
            Email Me
          </a>
        </div>
      </section>

      <footer className="py-6 bg-black text-center text-sm text-gray-500">
        © 2025 Ravien. All rights reserved.
      </footer>
    </main>
  );
}
