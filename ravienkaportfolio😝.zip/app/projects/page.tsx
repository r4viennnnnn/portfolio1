
export default function ProjectsPage() {
  const servers = [
    "NERDMC", "CREWMC", "RIFLEMC", "SOULMC", "FROZENMC", "MINEPIXEL",
    "XEONMC", "HYPERPIXEL", "ELITEMC", "VOIDNET", "MINEBEACH", "POSIDIANMC",
    "QUARTZMC", "TITANMC", "NOVANET"
  ];

  return (
    <main className="min-h-screen bg-gradient-to-br from-purple-800 via-black to-purple-900 flex items-center justify-center px-4 py-10">
      <div className="bg-[#1f1f1f] w-full max-w-7xl rounded-3xl shadow-lg overflow-hidden grid grid-cols-1 md:grid-cols-[300px_1fr]">
        <div className="bg-[#2c2c2c] flex flex-col items-center justify-between p-6 text-center">
          <div>
            <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-purple-500 mb-4">
              <img src="https://via.placeholder.com/150" alt="Profile" className="w-full h-full object-cover" />
            </div>
            <h1 className="text-2xl font-bold text-white">Ravien</h1>
            <p className="text-gray-400 mt-2">Professional Full Stack Developer.</p>
            <div className="flex justify-center space-x-4 mt-4 text-white text-lg">
              <i className="fab fa-discord" />
              <i className="fab fa-github" />
              <i className="fas fa-link" />
            </div>
          </div>
          <a href="https://discord.com/users/ravien.exe" className="mt-6 px-5 py-2 bg-white text-black rounded-full shadow hover:bg-gray-200 transition">
            Discord : ravien.exe
          </a>
          <p className="text-gray-500 text-sm mt-6">© 2025 All rights reserved.</p>
        </div>

        <div className="bg-[#121212] p-8 overflow-y-auto">
          <h2 className="text-white text-2xl font-semibold mb-6">My Previous Developed Servers</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {servers.map((srv, i) => (
              <div
  key={i}
  className={
    `text-white text-center px-4 py-3 rounded-lg transition shadow
    ${srv === "SOULMC"
      ? "bg-gradient-to-r from-pink-600 to-purple-600 shadow-pink-500/50"
      : "bg-[#1c1c1c] hover:bg-[#2b2b2b]"}`
  }
>
  {srv}
</div>

            ))}
          </div>
        </div>
      </div>
    </main>
  );
}
